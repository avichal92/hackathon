package com.citi.hackathon.service;

import java.util.List;

import com.citi.hackathon.data.CalcTable;
import com.citi.hackathon.data.RelationTable;

public class ValidationService {
	
	List<RelationTable> relationTableList;
	List<CalcTable> calcTableDataList;
	
	public ValidationService(List<RelationTable> relationTableList, List<CalcTable> calcTableDataList) {
		this.relationTableList = relationTableList;
		this.calcTableDataList = calcTableDataList;
	}
	
	
	public boolean isValidNode(String nodeName) {
		boolean validNode = false;
		validNode = relationTableList.stream()
				.anyMatch(r -> (r.getrParent().equals(nodeName) || r.getrChild().equals(nodeName)));

		if (!validNode) {
			validNode = calcTableDataList.stream().anyMatch(
					calcData -> (calcData.getcParent().equals(nodeName) || calcData.getcChild().equals(nodeName)));
		}

		return validNode;
	}
	
	public boolean isExpUpdateAllowed(String nodeName) {
		return calcTableDataList.stream().filter(calcData -> calcData.getcParent().equalsIgnoreCase(nodeName)).findFirst().isPresent();
	}
	/*
	 * public boolean isValidPeriod(String period) {
	 * 
	 * }
	 */
}
