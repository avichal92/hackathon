package com.citi.hackathon;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.citi.hackathon.data.CalcTable;
import com.citi.hackathon.data.CalcTableData;
import com.citi.hackathon.data.PeriodTable;
import com.citi.hackathon.data.PeriodTableData;
import com.citi.hackathon.data.RelationTable;
import com.citi.hackathon.data.RelationTableData;
import com.citi.hackathon.data.TimePeriodDefaultValueMapping;
import com.citi.hackathon.data.TimePeriodTable;
import com.citi.hackathon.data.TimePeriodTableData;
import com.citi.hackathon.domain.TreeNode;
import com.citi.hackathon.service.ExpenseCalcService;
import com.citi.hackathon.service.UpdateNodeService;
import com.citi.hackathon.service.ValidationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class HackathonApplication {
	
	static final int NODE_INDEX = 0;
	static final int NODE_VALUE_INDEX = 1;
	static final int EXPRESSION_INDEX = 1;

	static Map<String, Map<String, Double>> nodePeriodValueMapData = PeriodTableData.populateNodePeriodValueMap();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RelationTableData rtd = new RelationTableData();
		List<RelationTable> relationTableList = rtd.populateRelation();
		RelationTableData.printRelationData(relationTableList);

		CalcTableData ctd = new CalcTableData();
		List<CalcTable> calcTableDataList = ctd.populateCalcTable();
		CalcTableData.printCalcData(calcTableDataList);

		PeriodTableData.printPeriodTableData(nodePeriodValueMapData);

		TimePeriodTableData tptd = new TimePeriodTableData();
		List<TimePeriodTable> timePeriodTableList = tptd.populateTimePeriod();
		TimePeriodTableData.printTimePeriodTableData(timePeriodTableList);
		
		//ExpenseCalcService.defaultRelationMap = TimePeriodDefaultValueMapping.initDateValue();

		ValidationService vs = new ValidationService(relationTableList, calcTableDataList);
		ExpenseCalcService ncs = new ExpenseCalcService();
		UpdateNodeService uns = new UpdateNodeService(calcTableDataList);
		
		System.out.println("ENTER THE CYCLIC DEPTH VALUE FOR THE TREE:");
		System.out.println();
		Scanner scVal = new Scanner(System.in);
		String cycleDeptValue = scVal.nextLine();
		try{
			ExpenseCalcService.depthCycle = Integer.parseInt(cycleDeptValue);
		}catch(NumberFormatException ex){
			System.out.println("Incorrect depth value is entered setting it to default 3");
		}
		System.out.println("TREE STRUCTURE FROM THE GIVEN DATA INPUT:");
		System.out.println();
		//TreeNode root = ncs.createRootNode("Electronics");
		//ncs.print(root, 0);
		System.out.println("======================================================");
		System.out.println();
		TreeNode node;
		Scanner sc = new Scanner(System.in);
		String str;
		boolean exitFlag = false;
		String values[] = new String[3];
		
		
		String timePeriod = "201901";
		ExpenseCalcService ncst = new ExpenseCalcService(nodePeriodValueMapData, timePeriod);
		System.out.println("======================================================");
		TreeNode tRoot = ncst.createRootNode("Electronics");
		System.out.println("======================================================");
		ncs.print(tRoot, 0);
		PeriodTableData.printPeriodTableData(nodePeriodValueMapData);
		ExpenseCalcService ecalc = new ExpenseCalcService(nodePeriodValueMapData, timePeriodTableList);
		/*System.out.println("============PERIOD TREE==========================================");
		ExpenseCalcService ecalc = new ExpenseCalcService(nodePeriodValueMapData, timePeriodTableList);
		tRoot = ecalc.createRootNode("Electronics");
		System.out.println();
		System.out.println("Tree with Each Node containing data for multiple timeperiods:::");
		System.out.println();
		ecalc.printNode(tRoot, 0, null);
		System.out.println("======================================================");*/
		//ecalc.printJsonNode(tRoot, 0 , null);
		//ecalc.printJson(tRoot);
		
		
		/*
		 * ObjectMapper mapper = new ObjectMapper(); TreeNode treenode =
		 * mapper.convertValue(tRoot, TreeNode.class); JsonNode jsonInString =
		 * mapper.valueToTree(treenode); System.out.println(jsonInString);
		 */
		/*
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode objectNode1 = mapper.createObjectNode();
		// ecalc.generateJsonForTreeNode(tRoot);
		
		 ObjectNode tobjnode = ecalc.createRootJsonNode(tRoot);
		 try {
		 		
				System.out.println(" "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tobjnode));
				
	} catch (JsonProcessingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
		
		System.out.println();
		do {
			System.out.println();
			System.out.print("Enter Time Period to Generate Tree : or PRESS '1' TO EXIT:");
			System.out.println();
			str = sc.nextLine();
			String timePrd = str;
			if("1".equals(str)){
				System.out.println("Exit.....!!!!");
				break;
			}
			List<TimePeriodTable> timePeriodList = new ArrayList<TimePeriodTable>();
			timePeriodList.add(new TimePeriodTable(str));
			ExpenseCalcService expService = new ExpenseCalcService(nodePeriodValueMapData, timePeriodList);
			expService.setTimePeriod(str);
			TreeNode pTree = expService.createRootNode("Electronics");
			System.out.print("TREE FOR THE GIVEN Time Period : \" " + str + "\"\n");
			System.out.println("================================================");
			
			
			expService.createPeriodTree(pTree,0,str);
			expService.printNode(pTree, 0, str);
			
			do{
				System.out.println();
				System.out.print("(2) UPDATE NODE EXPRESSION OR VALUE "+ "\n");
				System.out.print("(3) TRAVERESE"+ "\n");
				System.out.print("(0) GO BACK..!!"+ "\n");
				System.out.print("CHOOSE YOUR OPTION:");
				str = sc.nextLine();
				
				switch(str){
				case"2":
					System.out.println();
					System.out.println("ENTER NODE NAME: ");
					values[0]= sc.nextLine();
					
					
					if(values.length==3) {
						if(values[NODE_INDEX]!=null && vs.isValidNode(values[NODE_INDEX]) && vs.isExpUpdateAllowed(values[NODE_INDEX])) {
							System.out.print("(1) UPDATE THE VALUE"+ "\n");
							System.out.print("(2) UPDATE THE EXPRESSION"+ "\n");
							System.out.print("CHOOSE YOUR OPTION:");
							str = sc.nextLine();
							switch(str) {
							
							case "1":
								System.out.println("ENTER VALUE TO UPDATE: ");
								System.out.println();
								values[1] = sc.nextLine();
								/*System.out.println("ENTER DEPTH CYCLE VALUE : ");
								System.out.println();
								values[2] = sc.nextLine();*/
								
								if(values.length==3){
									if(vs.isValidNode(values[NODE_INDEX])){
										try{
											System.out.println(" ");
											
											uns.updateNodeValue(pTree, values[NODE_INDEX], Double.parseDouble(values[NODE_VALUE_INDEX]));
											System.out.println(" ");
											ncs.print(pTree, 0);
											System.out.println(" ");
										}catch(NumberFormatException ex){
											System.out.println("ENTER NUMERICAL VALUE ONLY.");
										}
									}
								}else {
									System.out.println("INVALID NODE NAME"+ values[NODE_INDEX]+ "ENTERED. PLEASE ENTER A VALID NODE NAME" );
								}
								break;
							case "2":
								System.out.println("ENTER EXPRESSION TO UPDATE");
								System.out.println();
								values[1] = sc.nextLine();
								
								if(values.length==3) {
									if(values[NODE_INDEX]!=null && vs.isValidNode(values[NODE_INDEX]) && vs.isExpUpdateAllowed(values[NODE_INDEX])) {
										System.out.println("");
										uns.updateNodeExpression(pTree, values[NODE_INDEX], values[EXPRESSION_INDEX]);
										ncs.print(pTree, 0);
									}else {
										System.out.println(values[NODE_INDEX] + " , "+" THIS NODE IS NOT CALCULATIVE NODE. PLEASE ENTER EXPRESSION FOR CALCULATIVE NODE ONLY." );
									}
								}
								break;						
							}
							}else {
									System.out.println("ENTER VALUE TO UPDATE: ");
									System.out.println();
									values[1] = sc.nextLine();
									
									
									if(values.length==3){
										if(vs.isValidNode(values[NODE_INDEX])){
											try{
												System.out.println(" ");
												uns.updateNodeValue(pTree, values[NODE_INDEX], Double.parseDouble(values[NODE_VALUE_INDEX]));
												System.out.println(" ");
												ncs.print(pTree, 0);
												System.out.println(" ");
											}catch(NumberFormatException ex){
												System.out.println("ENTER NUMERICAL VALUE ONLY.");
											}
										}
									}else {
										System.out.println("INVALID NODE NAME"+ values[NODE_INDEX]+ "ENTERED. PLEASE ENTER A VALID NODE NAME" );
									}
							}
						
					}
					break;
				case "3":
						System.out.println(" ");
						ncs.print(pTree, 0);
						System.out.println(" ");
						break;
						
				case "0": 
						exitFlag = true;
						break;		
			    default:
			    	System.out.println("INVALID OPTION");
				}
				
			}while (!exitFlag);
			
		 System.out.println("================================================");
			
		} while (true);
	
	}

}
