package com.citi.hackathon.data;

public class CalcTable {
	private String cParent;
	private String cChild;
	private String calcExp;

	public CalcTable(String cParent, String cChild, String calcExp) {
		this.cParent = cParent;
		this.cChild = cChild;
		this.calcExp = calcExp;
	}

	public String getcParent() {
		return cParent;
	}

	public void setcParent(String cParent) {
		this.cParent = cParent;
	}

	public String getcChild() {
		return cChild;
	}

	public void setcChild(String cChild) {
		this.cChild = cChild;
	}

	public String getCalcExp() {
		return calcExp;
	}

	public void setCalcExp(String calcExp) {
		this.calcExp = calcExp;
	}

}
