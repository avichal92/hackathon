package com.citi.hackathon.data;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.citi.hackathon.util.json.JsonInputVO;
import com.citi.hackathon.util.json.Node;
import com.citi.hackathon.util.json.Value;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TimePeriodDefaultValueMapping {
	
	static Map<String, String> periodMap = new HashMap<String, String>();
	static Map<String, String> dateMap = new HashMap<String, String>();
	static String  fileName = "dateinput.json";
	
	
	/*public static Map<String, String> populateDateValueMap(){
		ObjectMapper mapper = new ObjectMapper();
		try {
		
			System.out.println(System.getProperty("user.dir"));
			
			File file = new File(System.getProperty("user.dir") + "\\src\\resources\\"+ fileName);
			JsonInputVO obj = mapper.readValue(file, JsonInputVO.class);
			
			/*List<Node> nodeList = obj.getNodes();
			List<Value> values = new ArrayList<Value>();
			for (Node n : nodeList) {
				dateMap = new HashMap<String, Double>();
				 values =  n.getValues();
				for (Value v : values) {
					periodValueMapData.put(v.getPeriod(), Double.parseDouble(v.getValue()));
				}
				nodePeriodValueMapData.put(n.getNodeName(), periodValueMapData);
				
			}*/
		
			
		/*} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return nodePeriodValueMapData;
	}*/
/*	public static Map<String, String> populateTimePeriodMapping(){
		periodMap.put("201901", "201812");
		periodMap.put("201902", "201901");
		periodMap.put("201903","201902");
		return periodMap;
	}
	*/
	
	public static Map<String, String> initDateValue(){
		dateMap.put("Jan", "01");
		dateMap.put("Feb", "02");
		dateMap.put("Mar", "03");
		dateMap.put("Apr", "04");
		dateMap.put("May", "05");
		dateMap.put("Jun", "06");
		dateMap.put("Jul", "07");
		dateMap.put("Aug", "08");
		dateMap.put("Sep", "09");
		dateMap.put("Oct", "10");
		dateMap.put("Nov", "11");
		dateMap.put("Dec", "12");
		return dateMap;
	}
	
	
	

}
