package com.citi.hackathon.data;

import com.citi.hackathon.domain.TreeNode;

public class PeriodTreeTable {
	private String period;
	private TreeNode node;

	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public TreeNode getNode() {
		return node;
	}
	public void setNode(TreeNode node) {
		this.node = node;
	}
	
	

}
