package com.citi.hackathon.data;

public class TimePeriodTable {
	
	private String timePeriod;
	
	public TimePeriodTable(String timePeriod) {
		this.timePeriod = timePeriod;
	}

	public String getTimePeriod() {
		return timePeriod;
	}

	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}
	
}
