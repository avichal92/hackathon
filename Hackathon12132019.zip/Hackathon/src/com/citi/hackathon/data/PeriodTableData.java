package com.citi.hackathon.data;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.citi.hackathon.util.json.JsonInputVO;
import com.citi.hackathon.util.json.Node;
import com.citi.hackathon.util.json.Value;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PeriodTableData {
	
	
	private static Map<String, Map<String, Double>> nodePeriodValueMapData = new HashMap<String, Map<String, Double>>(); 
	private static Map<String, Double> periodValueMapData = null;
	static String  fileName = "jsoninput.json";
	
	
	public static Map<String, Map<String, Double>> populateNodePeriodValueMap(){
		ObjectMapper mapper = new ObjectMapper();
		try {
		
			System.out.println(System.getProperty("user.dir"));
			
			File file = new File(System.getProperty("user.dir") + "\\src\\resources\\"+ fileName);
			JsonInputVO obj = mapper.readValue(file, JsonInputVO.class);
			
			List<Node> nodeList = obj.getNodes();
			List<Value> values = new ArrayList<Value>();
			for (Node n : nodeList) {
				periodValueMapData = new HashMap<String, Double>();
				 values =  n.getValues();
				for (Value v : values) {
					periodValueMapData.put(v.getPeriod(), Double.parseDouble(v.getValue()));
				}
				nodePeriodValueMapData.put(n.getNodeName(), periodValueMapData);
				
			}
		
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nodePeriodValueMapData;
		/*
		 * periodValueMapData = new HashMap<String, Double>();
		 * periodValueMapData.put("201901", 5.0); periodValueMapData.put("201902", 6.0);
		 * periodValueMapData.put("201903", 7.0);
		 * nodePeriodValueMapData.put("Laptop",periodValueMapData); periodValueMapData =
		 * new HashMap<String, Double>(); periodValueMapData.put("201901", 4.0);
		 * periodValueMapData.put("201902", 5.0); periodValueMapData.put("201903", 6.0);
		 * nodePeriodValueMapData.put("Monitor",periodValueMapData); periodValueMapData
		 * = new HashMap<String, Double>(); periodValueMapData.put("201901", 7.0);
		 * periodValueMapData.put("201902", 8.0); periodValueMapData.put("201903", 9.0);
		 * nodePeriodValueMapData.put("Keyboard",periodValueMapData); periodValueMapData
		 * = new HashMap<String, Double>(); periodValueMapData.put("201901", 2.0);
		 * periodValueMapData.put("201902", 3.0); periodValueMapData.put("201903", 4.0);
		 * nodePeriodValueMapData.put("CPU",periodValueMapData); periodValueMapData =
		 * new HashMap<String, Double>(); periodValueMapData.put("201901", 9.0);
		 * periodValueMapData.put("201902", 4.0); periodValueMapData.put("201903", 7.0);
		 * nodePeriodValueMapData.put("Samsung",periodValueMapData); periodValueMapData
		 * = new HashMap<String, Double>(); periodValueMapData.put("201901", 5.0);
		 * periodValueMapData.put("201902", 2.0); periodValueMapData.put("201903", 8.0);
		 * nodePeriodValueMapData.put("Google",periodValueMapData); periodValueMapData =
		 * new HashMap<String, Double>(); periodValueMapData.put("201901", 6.0);
		 * periodValueMapData.put("201902", 2.0); periodValueMapData.put("201903", 1.0);
		 * nodePeriodValueMapData.put("Apple",periodValueMapData); periodValueMapData =
		 * new HashMap<String, Double>(); periodValueMapData.put("201901", 7.0);
		 * periodValueMapData.put("201902", 6.0); periodValueMapData.put("201903", 9.0);
		 * nodePeriodValueMapData.put("Batteries",periodValueMapData);
		 * periodValueMapData = new HashMap<String, Double>();
		 * periodValueMapData.put("201901", 1.0); periodValueMapData.put("201902", 5.0);
		 * periodValueMapData.put("201903", 3.0);
		 * nodePeriodValueMapData.put("Headset",periodValueMapData);
		 * 
		 * return nodePeriodValueMapData;
		 */	}

	

	public static void printPeriodTableData(Map<String, Map<String, Double>> nodePeriodValueMapData) {
		System.out.println("PERIOD TABLE DATA:");
	/*	System.out.println("|-----------------------------------------------");
		System.out.println("|\t"+"NODENAME "+"\t-->\t"+"PERIOD"+"\t-->\t"+"VALUE");
		System.out.println("|-----------------------------------------------");
		for (PeriodTable p: periodTableList) {
			System.out.println("|\t"+p.getNodeName()+"\t-->\t"+p.getPeriod()+"\t-->\t"+p.getValue());
			System.out.println("|----------------------------------------------");
		}
		*/
	
		for (String key : nodePeriodValueMapData.keySet()) {
			
			System.out.println(key + " : " );
			
			for (String key1: nodePeriodValueMapData.get(key).keySet()) {
				System.out.println("\t"+key1 + " --> " +nodePeriodValueMapData.get(key).get(key1));
			}
			
		}

	}

}
