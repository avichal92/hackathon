package com.citi.hackathon.service;

import java.util.List;

import com.citi.hackathon.data.CalcTable;
import com.citi.hackathon.data.CalcTableData;
import com.citi.hackathon.domain.TreeNode;

public class UpdateNodeService {
	List<CalcTable> calcTableDataList = null;
	ExpenseCalcService ecs = new ExpenseCalcService();
	//default value is 5
	public static int deptValue = 5;
	
	public UpdateNodeService(List<CalcTable> calcTableDataList){
		this.calcTableDataList = calcTableDataList;
	}
	
	public void updateNodeValue(TreeNode root, String inputNodeName, Double value){
		TreeNode node = findNode(inputNodeName, root);
		node.getNodePeriodValueMap().put(node.getTimePeriod(),value);
		node.setValue(value);
		updateTree(node);
	}
	
	public void updateNodeExpression(TreeNode root, String inputNodeName, String expression) {
		for (CalcTable calcTable : calcTableDataList) {
			if (calcTable.getcParent().equalsIgnoreCase(inputNodeName)) {
				calcTable.setCalcExp(expression);
			}
		}
		CalcTableData.printCalcData(calcTableDataList);
		TreeNode node = findNode(inputNodeName, root);
		node.setExpr(expression);
		node.setValue(ecs.calculateValue(node));
		node.getNodePeriodValueMap().put(node.getTimePeriod(),node.getValue());
		updateTree(node);
	}

	private TreeNode findNode(String inputNodeName, TreeNode root) {
		TreeNode resultNode = null;
		List<TreeNode> childLst = root.getChildList();

		if (root.getNodeName().equals(inputNodeName)) {
			return root;
		} else {
			for (TreeNode child : childLst) {
				if(resultNode == null){//This check needs to made else you wont be able the inner value updation like 'samsung'
				resultNode = findNode(inputNodeName, child);
				if (child.getNodeName().equalsIgnoreCase(inputNodeName)){
					System.out.println("Matched " + child.getNodeName());
					return resultNode;
				}
			}
			}
		}
		return resultNode;

	}
	

	private void updateTree(TreeNode inputNode) {
		int cntdept = 0;
		TreeNode parent = inputNode.getParent();
		while (parent != null && cntdept <deptValue) {
			parent.setValue(ecs.calculateValue(parent));
			parent.getNodePeriodValueMap().put(parent.getTimePeriod(),parent.getValue());
			parent = parent.getParent();
			cntdept++;
		}
	}

}
