package com.citi.hackathon.data;

import java.util.ArrayList;
import java.util.List;

public class RelationTableData {
	RelationTable rt1 = new RelationTable("Electronics", "Computer");
	RelationTable rt2 = new RelationTable("Electronics", "PhoneAccessories");
	RelationTable rt3 = new RelationTable("IOS", "Apple");

	List<RelationTable> relationTableList = new ArrayList<RelationTable>();

	public List<RelationTable> populateRelation() {
		relationTableList.add(rt1);
		relationTableList.add(rt2);
		relationTableList.add(rt3);
		return relationTableList;
	}

	public static void printRelationData(List<RelationTable> relationTableList) {
		//populateRelation();
		System.out.println("RELATION TABLE DATA:");
		System.out.println("|-----------------------------------------------");
		System.out.println("|\t"+"PARENT "+"\t-->\t"+"CHILD"+"\t");
		System.out.println("|-----------------------------------------------");
		for (RelationTable l: relationTableList) {
			System.out.println("|\t"+l.getrParent()+"\t-->\t"+l.getrChild()+"\t");
			System.out.println("|----------------------------------------------");
		}
		
		System.out.println();
	}

	
	
}
