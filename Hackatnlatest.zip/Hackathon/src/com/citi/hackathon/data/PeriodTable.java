package com.citi.hackathon.data;

import java.util.Map;

public class PeriodTable {
	

	Map<String, Map<String, Double>> nodePeriodValueMap; 
	
	public PeriodTable(Map<String, Map<String, Double>> nodePeriodValueMap) {
		
		this.nodePeriodValueMap = nodePeriodValueMap;
	}
	
	public Map<String, Map<String, Double>> getNodePeriodValueMap() {
		return nodePeriodValueMap;
	}

	public void setNodePeriodValueMap(Map<String, Map<String, Double>> nodePeriodValueMap) {
		this.nodePeriodValueMap = nodePeriodValueMap;
	}
	
}
