package com.citi.hackathon.util;

import java.util.List;
import java.util.Optional;
import java.util.Stack;

import com.citi.hackathon.domain.TreeNode;

public class ExpressionParser {
	
	public static Double evaluateExpr(String expr, List<TreeNode> childList) {

		String[] tokens = expr.split(" ");

		Stack<Double> valueStack = new Stack<Double>();
		Stack<String> opStack = new Stack<String>();
		Optional<TreeNode> optNode = null;

		for (int i = 0; i < tokens.length; i++) {
			String token = tokens[i];
            // get node value if token is not a symbol   
			if (!isSymbol(token.charAt(0))) {
				optNode = childList.stream().filter(c -> c.getNodeName().equalsIgnoreCase(token)).findFirst();
				valueStack.push(optNode.isPresent() ? optNode.get().getValue() : Double.parseDouble(token));

			} else if (tokens[i].equals("("))
				opStack.push(tokens[i]);

			// Closing brace encountered, solve entire brace
			else if (tokens[i].equals(")")) {
				while (!opStack.peek().equals("(")) {
					valueStack.push(applyOperation(opStack.pop(), valueStack.pop(), valueStack.pop()));
				}
				opStack.pop();
			}

			// Current token is an operator.
			else if (tokens[i].equals("+") || tokens[i].equals("-") || tokens[i].equals("*") || tokens[i].equals("/")) {
			
				while (!opStack.empty() && checkPrecedence(tokens[i].charAt(0), opStack.peek().charAt(0))) {
					valueStack.push(applyOperation(opStack.pop(), valueStack.pop(), valueStack.pop()));
				}

				// Push current token to 'opStack'.
				opStack.push(tokens[i]);
			}
		}
		
		while (!opStack.empty()) {
			valueStack.push(applyOperation(opStack.pop(), valueStack.pop(), valueStack.pop()));
		}

		return valueStack.pop();
	}

	public static Double evaluateExpression(String expr, List<TreeNode> childList) {

		String[] tokens = expr.split(" ");

		Stack<Double> valueStack = new Stack<Double>();
		Stack<String> opStack = new Stack<String>();
		Optional<TreeNode> optNode = null;

		for (int i = 0; i < tokens.length; i++) {
			String token = tokens[i];
            // get node value if token is not a symbol   
			if (!isSymbol(token.charAt(0))) {
				optNode = childList.stream().filter(c -> c.getNodeName().equalsIgnoreCase(token)).findFirst();
				valueStack.push(optNode.isPresent() ? optNode.get().getValue() : Double.parseDouble(token));

			} else if (tokens[i].equals("("))
				opStack.push(tokens[i]);

			// Closing brace encountered, solve entire brace
			else if (tokens[i].equals(")")) {
				while (!opStack.peek().equals("(")) {
					valueStack.push(applyOperation(opStack.pop(), valueStack.pop(), valueStack.pop()));
				}
				opStack.pop();
			}

			// Current token is an operator.
			else if (tokens[i].equals("+") || tokens[i].equals("-") || tokens[i].equals("*") || tokens[i].equals("/")) {
			
				while (!opStack.empty() && checkPrecedence(tokens[i].charAt(0), opStack.peek().charAt(0))) {
					valueStack.push(applyOperation(opStack.pop(), valueStack.pop(), valueStack.pop()));
				}

				// Push current token to 'opStack'.
				opStack.push(tokens[i]);
			}
		}
		
		while (!opStack.empty()) {
			valueStack.push(applyOperation(opStack.pop(), valueStack.pop(), valueStack.pop()));
		}

		return valueStack.pop();
	}

	// Returns true if 'op2' has higher or same precedence as 'op1',
	// otherwise returns false.
	private static boolean checkPrecedence(char op1, char op2) {
		if (op2 == '(' || op2 == ')')
			return false;
		if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
			return false;
		else
			return true;
	}

	// A utility method to apply an operator 'op' on operands 'a'
	// and 'b'. Return the result.
	private static Double applyOperation(String op, Double num1, Double num2) {
		switch (op) {
		case "+":
			return num2 + num1;
		case "-":
			return num2 - num1;
		case "*":
			return num2 * num1;
		case "/":
			if (num1 == 0.0)
				throw new UnsupportedOperationException("Cannot divide by zero");
			return num2 / num1;
		}
		return 0.0;
	}

	private static boolean isSymbol(char token) {
		Boolean symbol = false;
		switch (token) {
		case '(':
		case '+':
		case '-':
		case '/':
		case '*':
		case '%':
		case ')':
			symbol = true;
			break;
		default:
			symbol = false;
		}
		return symbol;
	}
}
