package com.citi.hackathon.domain;

import java.util.List;
import java.util.Map;

public class TreeNode {

	private TreeNode parent;
	private String nodeName;
	private Boolean isCalcNode;
	private List<TreeNode> childList;
	private String timePeriod;
	private Double value;
	private String expr;
	private String path;
	private Map<String, Double> nodePeriodValueMap;

	public String getExpr() {
		return expr;
	}

	public void setExpr(String expr) {
		this.expr = expr;
	}

	public TreeNode getParent() {
		return parent;
	}

	public void setParent(TreeNode parent) {
		this.parent = parent;
	}

	public Boolean getIsCalcNode() {
		return isCalcNode;
	}

	public void setIsCalcNode(Boolean isCalcNode) {
		this.isCalcNode = isCalcNode;
	}

	public List<TreeNode> getChildList() {
		return childList;
	}

	public void setChildList(List<TreeNode> childList) {
		this.childList = childList;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getTimePeriod() {
		return timePeriod;
	}

	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}

	public Map<String, Double> getNodePeriodValueMap() {
		return nodePeriodValueMap;
	}

	public void setNodePeriodValueMap(Map<String, Double> nodePeriodValueMap) {
		this.nodePeriodValueMap = nodePeriodValueMap;
	}

	/*
	 * public String toString() { return nodeName + "[ Value:" + value +
	 * "; Expression:" + (expr != null ? expr : "N/A") + "; Path:" +path +"]";
	 * 
	 * }
	 */
	public String toString() {
		if (nodePeriodValueMap != null) {
			return nodeName + "[ nodePeriodValueMap:" + nodePeriodValueMap + "; Expression:"
					+ (expr != null ? expr : "N/A") + "; Path:" + path + "]";
		} else {
			return nodeName + "[ value:" + value + "; Expression:"
					+ (expr != null ? expr : "N/A") + "; Path:" + path + "]";
		}

	}

}
