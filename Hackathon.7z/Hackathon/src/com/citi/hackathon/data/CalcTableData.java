package com.citi.hackathon.data;

import java.util.ArrayList;
import java.util.List;

public class CalcTableData {

	CalcTable ct1 = new CalcTable("Computer", "Laptop", "( Laptop + PC ) / 2");
	CalcTable ct2 = new CalcTable("Computer", "PC", "( Laptop + PC ) / 2");
	//CalcTable ct13 = new CalcTable("Laptop", "Electronics", "( Electronics ) / 2");
	CalcTable ct3 = new CalcTable("PC", "Monitor", "( Monitor + Keyboard + CPU )");
	CalcTable ct4 = new CalcTable("PC", "keyboard", "( Monitor + Keyboard + CPU )");
	CalcTable ct5 = new CalcTable("PC", "CPU", "( Monitor + Keyboard + CPU )");
	CalcTable ct6 = new CalcTable("PhoneAccessories", "SmartPhones", "( SmartPhones + Batteries + Headset )");
	CalcTable ct7 = new CalcTable("PhoneAccessories", "Batteries", "( SmartPhones + Batteries + Headset )");
	CalcTable ct8 = new CalcTable("PhoneAccessories", "Headset", "( SmartPhones + Batteries + Headset )");
	CalcTable ct9 = new CalcTable("SmartPhones", "Android", "( Android + IOS ) / 2");
	CalcTable ct10 = new CalcTable("SmartPhones", "IOS", "( Android + IOS ) / 2");
	CalcTable ct11 = new CalcTable("Android", "Samsung", "( Samsung + Google ) / 2");
	CalcTable ct12 = new CalcTable("Android", "Google", "( Samsung + Google ) / 2");
	CalcTable ct13 = new CalcTable("Google", "PhoneAccessories", "( PhoneAccessories ) / 2");
	
	

	List<CalcTable> calcTableList = new ArrayList<CalcTable>();

	public List<CalcTable> populateCalcTable() {
		calcTableList.add(ct1);
		calcTableList.add(ct2);
		calcTableList.add(ct3);
		calcTableList.add(ct4);
		calcTableList.add(ct5);
		calcTableList.add(ct6);
		calcTableList.add(ct7);
		calcTableList.add(ct8);
		calcTableList.add(ct9);
		calcTableList.add(ct10);
		calcTableList.add(ct11);
		calcTableList.add(ct12);
		calcTableList.add(ct13);

		return calcTableList;
	}

	public static void printCalcData(List<CalcTable> calcTableList) {
		//populateCalcTable();
		System.out.println("CALCULATED TABLE DATA");
		System.out.println("|------------------------------------------------------------------------------------");
		System.out.println("|"+"\tParent\t"+"-->"+"\tChild\t"+"-->" +"\tExpression\t\t");
		System.out.println("|------------------------------------------------------------------------------------");
		for (CalcTable l: calcTableList) {
			System.out.println("|\t"+l.getcParent()+"\t"+"-->"+"\t"+l.getcChild()+"\t"+"-->" +"\t"+l.getCalcExp());
			System.out.println("|--------------------------------------------------------------------------------");
		}
		System.out.println();
	}
		
}
