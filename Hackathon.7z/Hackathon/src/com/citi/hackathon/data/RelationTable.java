package com.citi.hackathon.data;

import com.citi.hackathon.domain.TreeNode;

public class RelationTable {
	private String rParent;
	private String rChild;

	public RelationTable(String rParent, String rChild) {
		this.rParent = rParent;
		this.rChild = rChild;
	}

	public String getrParent() {
		return rParent;
	}

	public void setrParent(String rParent) {
		this.rParent = rParent;
	}

	public String getrChild() {
		return rChild;
	}

	public void setrChild(String rChild) {
		this.rChild = rChild;
	}

}
