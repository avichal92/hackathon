package com.citi.hackathon.data;

import java.util.ArrayList;
import java.util.List;

public class TimePeriodTableData {
	
	List<TimePeriodTable> timePeriodList = new ArrayList<TimePeriodTable>();
	
	TimePeriodTable tpt1 = new TimePeriodTable("201901");
	TimePeriodTable tpt2 = new TimePeriodTable("201902");
	TimePeriodTable tpt3 = new TimePeriodTable("201903");
	
	public List<TimePeriodTable> populateTimePeriod(){
		timePeriodList.add(tpt1);
		timePeriodList.add(tpt2);
		timePeriodList.add(tpt3);
		
		return timePeriodList;
	}
	
	public static void printTimePeriodTableData(List<TimePeriodTable> timePeriodList) {
		//populateRelation();
		System.out.println("TIME PERIOD TABLE DATA:");
		System.out.println("|-----------------------------------------------");
		System.out.println("|\t"+"TIME PERIOD");
		System.out.println("|-----------------------------------------------");
		for (TimePeriodTable t: timePeriodList) {
			System.out.println("|\t"+t.getTimePeriod());
			System.out.println("|----------------------------------------------");
		}
		
		System.out.println();
	}
	

}
