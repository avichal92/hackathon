package com.citi.hackathon.service;

import java.util.List;

import com.citi.hackathon.data.CalcTable;
import com.citi.hackathon.data.CalcTableData;
import com.citi.hackathon.domain.TreeNode;

public class UpdateNodeService {
	List<CalcTable> calcTableDataList = null;
	ExpenseCalcService ecs = new ExpenseCalcService();
	TreeNode foundNode;
	
	public UpdateNodeService(List<CalcTable> calcTableDataList){
		this.calcTableDataList = calcTableDataList;
	}
	
	public void updateNodeValue(TreeNode root, String inputNodeName, Double value){
		TreeNode node = findNode(inputNodeName, root);
		node.getNodePeriodValueMap().put(node.getTimePeriod(),value);
		node.setValue(value);
		updateTree(node);
	}
	
	public void updateNodeExpression(TreeNode root, String inputNodeName, String expression) {
		for (CalcTable calcTable : calcTableDataList) {
			if (calcTable.getcParent().equalsIgnoreCase(inputNodeName)) {
				calcTable.setCalcExp(expression);
			}
		}
		CalcTableData.printCalcData(calcTableDataList);
		TreeNode node = findNode(inputNodeName, root);
		node.setExpr(expression);
		node.setValue(ecs.calculateValue(node));
		node.getNodePeriodValueMap().put(node.getTimePeriod(),node.getValue());
		updateTree(node);
	}

	/*
	 * This logic returns the first found node in the tree and updates the parents above it
	 */
	/*private TreeNode findNode(String inputNodeName, TreeNode root) {
		TreeNode resultNode = null;
		List<TreeNode> childLst = root.getChildList();

		if (root.getNodeName().equals(inputNodeName)) {
			return root;
		} else {
			for (TreeNode child : childLst) {
				if(resultNode == null){//This check needs to made else you wont be able the inner value updation like 'samsung'
				resultNode = findNode(inputNodeName, child);
				if (child.getNodeName().equalsIgnoreCase(inputNodeName)){
					System.out.println("Matched " + child.getNodeName());
					return resultNode;
				}
			}
			}
		}
		return resultNode;

	}*/
	
	/*
	 * The below logic perform node search for the last node found in the tree and 
	 * Then after finding the node the corresponding parent node values get updated 
	 */
	private TreeNode findNode(String inputNodeName, TreeNode root) {
		List<TreeNode> childLst = root.getChildList();
		if (root.getNodeName().equals(inputNodeName)) {
			System.out.println("Matched with the node " + root.getNodeName());
			foundNode = root;
	    }
		for (TreeNode treeNode : childLst) {
			if (treeNode.getNodeName().equals(inputNodeName)) {
				System.out.println("Matched with the child node " + treeNode.getNodeName());
				foundNode = root;
		    }
			findNode(inputNodeName, treeNode);
		}
		return foundNode;
	}
	
	/*
	 * TODO
	 * Do we need to write a logic which will search all the nodes and update the parents for all the found node given for a specific node search
	 */
	

	private void updateTree(TreeNode inputNode) {
		TreeNode parent = inputNode.getParent();
		while (parent != null) {
			parent.setValue(ecs.calculateValue(parent));
			parent.getNodePeriodValueMap().put(parent.getTimePeriod(),parent.getValue());
			parent = parent.getParent();
		}
	}

}
