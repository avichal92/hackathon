package com.citi.hackathon.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import com.citi.hackathon.data.CalcTable;
import com.citi.hackathon.data.CalcTableData;
import com.citi.hackathon.data.RelationTable;
import com.citi.hackathon.data.RelationTableData;
import com.citi.hackathon.data.TimePeriodTable;
import com.citi.hackathon.domain.TreeNode;
import com.citi.hackathon.util.ExpressionParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ExpenseCalcService {

	RelationTableData rtd = new RelationTableData();
	List<RelationTable> relationTableList = rtd.populateRelation();
	CalcTableData ctd = new CalcTableData();
	List<CalcTable> calcTableDataList = ctd.populateCalcTable();
	static Map<String, Map<String, Double>> nodePeriodValueMapData;
	String timePeriod;
	TreeNode topRootNode;
	int cycleCount;
	

	List<TimePeriodTable> timePeriodTableList;
	ObjectMapper mapper = new ObjectMapper();
	ObjectNode objectNode1 = mapper.createObjectNode();
	public static int depthCycle = 3;
	
	String cycleOnChild;
	 
	 

	public ExpenseCalcService() {
	}

	public ExpenseCalcService(Map<String, Map<String, Double>> nodePeriodValueMapData, String timePeriod) {
		this.timePeriod = timePeriod;
		ExpenseCalcService.nodePeriodValueMapData = nodePeriodValueMapData;
	}

	public ExpenseCalcService(Map<String, Map<String, Double>> nodePeriodValueMapData,
			List<TimePeriodTable> timePeriodTableList) {
		this.timePeriodTableList = timePeriodTableList;
		ExpenseCalcService.nodePeriodValueMapData = nodePeriodValueMapData;
	}

	// create root node
	public TreeNode createRootNode(String nodeName) {

		TreeNode root = new TreeNode();

		Boolean calcFlag = isCalcNode(nodeName);
		root.setNodeName(nodeName);
		root.setIsCalcNode(calcFlag);
		root.setParent(null);
		root.setPath(nodeName);
		root.setTimePeriod(timePeriod);
		topRootNode = root;
		//depthMap.put(nodeName, new Integer(1));
		if (calcFlag) {
			root.setExpr(getExpression(nodeName));
		}
		List<TreeNode> ltn = getChildList(root);
		root.setChildList(ltn);
		return root;
		// print(root, 0);

	}

	// find out child nodes
	private List<TreeNode> getChildList(TreeNode root) {
		String nodeName = root.getNodeName();
		List<String> childNamesList = new ArrayList<String>();
		List<TreeNode> childNodeList = new ArrayList<TreeNode>();
		TreeNode tn = new TreeNode();
		if (root.getIsCalcNode()) {
			childNamesList = lookupCalcTable(nodeName);
		} else {
			childNamesList = lookupRelationTable(nodeName);
		}
		//This is to come out of the cycle after exdcution for given cyclic depth
		boolean cycleFound = false; 
		for (String name : childNamesList) {
			if((cycleFound = checkCycleForRoot(root, name))){
				break;
			}
		}
		if(cycleFound){
			childNamesList = new ArrayList<String>();
		}
		System.out.println("Root -> " + root.getNodeName());
		for (String childName : childNamesList) {
				tn = createNode(root, childName);
				childNodeList.add(tn);
		}
	 
		root.setChildList(childNodeList);
		root.setValue(calculateValue(root));
		if (nodePeriodValueMapData != null && timePeriodTableList != null) {
			root.setNodePeriodValueMap(calculatePeriodValueMap(root));
		}

		return childNodeList;
	}
	
	private boolean checkCycleForRoot(TreeNode root, String childName){
		TreeNode tempNode = root;
		boolean cycleBreakFound = false;
		int cnt = 0;
		while(tempNode!=null){
				if(tempNode.getNodeName().equalsIgnoreCase(childName)){
					
					if(cnt > depthCycle-1){
						cycleBreakFound = true;
						break;
					}
					cnt++;
				}
				tempNode = tempNode.getParent();
		}
		return cycleBreakFound;
	}

	// make child strings as nodes
	protected TreeNode createNode(TreeNode parent, String child) {

		TreeNode node = new TreeNode();
		Boolean calcFlag = isCalcNode(child);
		node.setNodeName(child);
		node.setParent(parent);
		node.setIsCalcNode(calcFlag);
		node.setPath(parent.getPath() + "-->" + child);
		node.setTimePeriod(parent.getTimePeriod());
		if (calcFlag) {
			node.setExpr(getExpression(child));
		}
		getChildList(node);

		return node;
	}

	public void print(TreeNode node, int index) {

		
		System.out.println(getIndentation(index) + node);
		for (TreeNode t : node.getChildList()) {
			print(t, index + 1);
		}
		

	}
	
	public void createPeriodTree(TreeNode node, int index , String period){
		 {
			if(period!=null && isValidPeriod(period) && node.getNodePeriodValueMap() != null) {
				
				Double currentPeriodVal = node.getNodePeriodValueMap().get(period);
				node.setNodePeriodValueMap(null);
				Map<String, Double> nodePeriodValueMap = new HashMap<>();
				nodePeriodValueMap.put(period, currentPeriodVal);
				node.setNodePeriodValueMap(nodePeriodValueMap);
			}
		}	
		for (TreeNode t : node.getChildList()) {
			createPeriodTree(t, index + 1 , period);
		}
	}
	
	public ObjectNode createRootJsonNode(TreeNode root) {

		 ObjectNode objectNode1 = mapper.createObjectNode();
		 objectNode1.put("nodeName", root.getNodeName());
		 objectNode1.put("path", root.getPath());
		 objectNode1.put("Expression", root.getExpr());
		
		 
		 ObjectNode periodValueObj =null;
		 Map<String, Double>  nodePeriodValueMap = root.getNodePeriodValueMap();
		 
		 if(nodePeriodValueMap != null && nodePeriodValueMap.size()>0) {
			 
			  ArrayNode periodValueArray = mapper.createArrayNode();
			  for (Entry<String, Double> entry : nodePeriodValueMap.entrySet()) {
				  periodValueObj = mapper.createObjectNode();
					 periodValueObj.put("period", entry.getKey());
					 periodValueObj.put("value", entry.getValue());
					 periodValueArray.add(periodValueObj);
			  }
		    					 
			 objectNode1.put("PeriodValueList", periodValueArray);
		 }
		 ArrayNode childList = getChildJsonList(root,objectNode1);
		 objectNode1.put("childList", childList);
		
		return objectNode1;
		// print(root, 0);

	}
	
	private ArrayNode getChildJsonList(TreeNode root,ObjectNode objectNode1) {
		 ArrayNode childList = mapper.createArrayNode();
		 for (TreeNode t : root.getChildList()) {
			 childList.add(createRootJsonNode(t));
			
			 
		 }
		
			return childList;
	}
	

	public void generateJsonForTreeNode(TreeNode root) {  
		

		
		//JsonNode rootNode = mapper.createObjectNode();
		 ObjectNode objectNode1 = mapper.createObjectNode();
		 objectNode1.put("nodeName", root.getNodeName());
		 objectNode1.put("path", root.getPath());
		 objectNode1.put("Expression", root.getExpr());
		
		 
		 ObjectNode periodValueObj =null;
		 Map<String, Double>  nodePeriodValueMap = root.getNodePeriodValueMap();
		 
		 if(nodePeriodValueMap != null && nodePeriodValueMap.size()>0) {
			 
			  ArrayNode periodValueArray = mapper.createArrayNode();
			  for (Entry<String, Double> entry : nodePeriodValueMap.entrySet()) {
				  periodValueObj = mapper.createObjectNode();
					 periodValueObj.put("period", entry.getKey());
					 periodValueObj.put("value", entry.getValue());
					 periodValueArray.add(periodValueObj);
			  }
		    					 
			 objectNode1.put("PeriodValueList", periodValueArray);
		 }
		 
		 try {
			 		
						System.out.println(" "+ mapper.writerWithDefaultPrettyPrinter().writeValueAsString(objectNode1));
						
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		  
			 for (TreeNode t : root.getChildList()) {
				 generateJsonForTreeNode(t);
			 }

			
		 
		 
		
	}
	
	public void printNode(TreeNode node, int index , String period) {
		 {
			if(period!=null && isValidPeriod(period) && node.getNodePeriodValueMap() != null) {
			
				System.out.println(getIndentation(index) + node.getNodeName()+ "[ nodePeriodValueMap:" +node.getNodePeriodValueMap() + "; nodePeriodValue:" + node.getNodePeriodValueMap().get(period) + "; Expression:"
						+ (node.getExpr() != null ? node.getExpr() : "N/A") + "; Path:" + node.getPath() + "]");
			}
			
			if(period == null && node.getNodePeriodValueMap() != null )
			{
				System.out.println(getIndentation(index) + node.getNodeName()+ "[ nodePeriodValueMap:" +node.getNodePeriodValueMap() + "; Expression:"
						+ (node.getExpr() != null ? node.getExpr() : "N/A") + "; Path:" + node.getPath() + "]");
			}

		}	
		for (TreeNode t : node.getChildList()) {
			printNode(t, index + 1 , period);
		}
        
	}
	public void printJsonNode(TreeNode node, int index , String period) {
		ObjectMapper Obj = new ObjectMapper(); 
		  
       
		 
			if(period!=null && isValidPeriod(period) && node.getNodePeriodValueMap() != null) {
			
				try {
					System.out.println(Obj.writeValueAsString(node));
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
			
			if(period == null && node.getNodePeriodValueMap() != null )
			{
				try {
					System.out.println(Obj.writeValueAsString(node));
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}

			
		for (TreeNode t : node.getChildList()) {
			printNode(t, index + 1 , period);
		}
       
	}
	private boolean isValidPeriod(String period)
	{
		if(timePeriodTableList!=null)
		{
			Iterator<TimePeriodTable> it  = timePeriodTableList.iterator();
			while(it.hasNext())
			{
				if(it.next().getTimePeriod().equalsIgnoreCase(period))
					return true;
			}
		}
		return false;
	}

	private String getIndentation(int index) {
		String indentation = "";
		for (int i = 0; i < index; i++) {
			indentation += "\t";
		}
		return indentation;
	}

	
	// to find the childs in the calc table
	protected List<String> lookupCalcTable(String nodeName) {

		List<String> childs = new ArrayList<String>();

		for (CalcTable calcTable : calcTableDataList) {
			if (calcTable.getcParent().equals(nodeName)) {
				childs.add(calcTable.getcChild());
			}
		}
		return childs;
	}

	// to find the childs in the relation table
	protected List<String> lookupRelationTable(String nodeName) {
		List<String> childs = new ArrayList<String>();

		for (RelationTable relationTable : relationTableList) {
			if (relationTable.getrParent().equals(nodeName)) {
				childs.add(relationTable.getrChild());
			}
		}

		return childs;

	}

	public Double calculateValue(TreeNode node) {
		Double val = 0.0;
		List<TreeNode> childList = node.getChildList();
		if (childList == null || childList.isEmpty()) {
			if (node.getTimePeriod() != null) {
				for (String nodeName : nodePeriodValueMapData.keySet()) {
					if (nodeName.equalsIgnoreCase(node.getNodeName())) {
						for (String timePeriod : nodePeriodValueMapData.get(nodeName).keySet()) {
							if (timePeriod.equalsIgnoreCase(node.getTimePeriod())) {
								val = nodePeriodValueMapData.get(nodeName).get(timePeriod);
							}
						}
					}
				}

			} else {
				val = 5.0;
			}

		}

		else if (node.getIsCalcNode()) {
			String expr = node.getExpr();
			val = ExpressionParser.evaluateExpr(expr, childList);
			if (node.getTimePeriod() != null) {
				saveToPeriodValueMapData(node, val);
			}

		} else {

			for (TreeNode child : childList) {
				val += child.getValue();
			}
			if (node.getTimePeriod() != null) {
				saveToPeriodValueMapData(node, val);
			}
		}
		return val;
	}

	public Map<String, Double> calculatePeriodValueMap(TreeNode node) {

		/*
		 * If it a leaf node get the periodvalue map from Data(nodePeriodValueMapData)
		 * and return it .
		 */

		Map<String, Double> periodValueMap = new HashMap<String, Double>();
		Double val = 0.0;
		List<TreeNode> childList = node.getChildList();
		if (childList == null || childList.isEmpty()) {
			for (String nodeName : nodePeriodValueMapData.keySet()) {
				if (nodeName.equalsIgnoreCase(node.getNodeName())) {
					periodValueMap = nodePeriodValueMapData.get(nodeName);
				}
			}

		} else if (node.getIsCalcNode()) {
			String expr = node.getExpr();
			for (TimePeriodTable timePeriod : timePeriodTableList) {
				for (TreeNode childNode : childList) {
					childNode.setValue(childNode.getNodePeriodValueMap().get(timePeriod.getTimePeriod()));
				}
				periodValueMap.put(timePeriod.getTimePeriod(), ExpressionParser.evaluateExpr(expr, childList));
			}
		} else {
			for (TimePeriodTable timePeriod : timePeriodTableList) {
				for (TreeNode childNode : childList) {

					childNode.setValue(childNode.getNodePeriodValueMap().get(timePeriod.getTimePeriod()));
					val += childNode.getNodePeriodValueMap().get(timePeriod.getTimePeriod());

				}
				periodValueMap.put(timePeriod.getTimePeriod(), val);
				val = 0.0;
			}
		}

		return periodValueMap;
	}

	private void saveToPeriodValueMapData(TreeNode node, Double val) {

		if (nodePeriodValueMapData.get(node.getNodeName()) != null) {
			nodePeriodValueMapData.get(node.getNodeName()).put(node.getTimePeriod(), val);
		} else {
			Map<String, Double> temp = new HashMap<String, Double>();
			temp.put(node.getTimePeriod(), val);
			nodePeriodValueMapData.put(node.getNodeName(), temp);
		}

	}

	protected String getExpression(String nodeName) {

		Optional<CalcTable> calcTableData = calcTableDataList.stream()
				.filter(c -> c.getcParent().equalsIgnoreCase(nodeName)).findFirst();

		return calcTableData.isPresent() ? calcTableData.get().getCalcExp() : null;

	}

	protected Boolean isCalcNode(String nodeName) {

		/*
		 * for (CalcTable calcData : calcTableDataList) { if
		 * (calcData.getcParent().equals(nodeName)) { return true; } }
		 * 
		 * return false;
		 */

		return calcTableDataList.stream().filter(calcData -> calcData.getcParent().equalsIgnoreCase(nodeName))
				.findFirst().isPresent();

	}
	public void setTimePeriod(String timePeriod) {
		this.timePeriod = timePeriod;
	}

}
